import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { MultiStepForm } from "@/components/ui/multi-step-form";
import { MatchCard } from "@/components/ui/match-card";
import { NotificationToast } from "@/components/ui/notification-toast";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Lightbulb } from "lucide-react";

export default function Matching() {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const [notification, setNotification] = useState<{
    show: boolean;
    title: string;
    message: string;
    type: 'success' | 'error' | 'info';
  }>({ show: false, title: '', message: '', type: 'success' });

  // Get userId from URL params
  const urlParams = new URLSearchParams(window.location.search);
  const userId = urlParams.get('userId');

  // Find matches
  const findMatchesMutation = useMutation({
    mutationFn: async () => {
      if (!userId) throw new Error('User ID is required');
      const response = await apiRequest('POST', '/api/matches/find', { userId: parseInt(userId) });
      return response.json();
    },
    onSuccess: (matches) => {
      queryClient.setQueryData(['/api/matches', userId], matches);
      if (matches.length === 0) {
        showNotification('No Matches Found', 'Try updating your skills or availability', 'info');
      } else {
        showNotification('Matches Found!', `Found ${matches.length} potential connections`, 'success');
      }
    },
    onError: (error: any) => {
      showNotification('Matching Failed', error.message || 'Please try again', 'error');
    },
  });

  // Get matches (from cache or trigger finding)
  const { data: matches = [], isLoading } = useQuery({
    queryKey: ['/api/matches', userId],
    queryFn: () => {
      findMatchesMutation.mutate();
      return [];
    },
    enabled: !!userId,
  });

  // Accept/reject match mutations
  const matchActionMutation = useMutation({
    mutationFn: async ({ matchId, status }: { matchId: number; status: string }) => {
      const response = await apiRequest('PATCH', `/api/matches/${matchId}`, { status });
      return response.json();
    },
    onSuccess: (result, variables) => {
      if (variables.status === 'accepted') {
        showNotification('Connection Request Sent!', 'Your match will be notified', 'success');
      } else {
        showNotification('Match Passed', 'Looking for more matches...', 'info');
      }
      // Refresh matches
      queryClient.invalidateQueries({ queryKey: ['/api/matches', userId] });
    },
    onError: (error: any) => {
      showNotification('Action Failed', error.message || 'Please try again', 'error');
    },
  });

  const handleAcceptMatch = (matchId: number) => {
    matchActionMutation.mutate({ matchId, status: 'accepted' });
  };

  const handleRejectMatch = (matchId: number) => {
    matchActionMutation.mutate({ matchId, status: 'rejected' });
  };

  const showNotification = (title: string, message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setNotification({ show: true, title, message, type });
  };

  const hideNotification = () => {
    setNotification(prev => ({ ...prev, show: false }));
  };

  const goBack = () => {
    setLocation(`/profile-setup?userId=${userId}`);
  };

  const viewResults = () => {
    setLocation(`/dashboard?userId=${userId}`);
  };

  // Auto-find matches on load
  useEffect(() => {
    if (userId && matches.length === 0 && !isLoading) {
      findMatchesMutation.mutate();
    }
  }, [userId]);

  if (!userId) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-slate-800 mb-4">Session Required</h2>
          <p className="text-slate-600 mb-4">Please complete profile setup first</p>
          <Button onClick={() => setLocation('/registration')}>
            Start Over
          </Button>
        </div>
      </div>
    );
  }

  const steps = [
    { title: "Your Perfect Matches! 🎯", description: "Your Matches" }
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b border-slate-200">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-xl flex items-center justify-center shadow-lg">
                <span className="text-white font-bold text-lg">SS</span>
              </div>
              <div>
                <h1 className="text-xl font-bold text-slate-800">SkillSync</h1>
                <p className="text-xs text-slate-500">Connect • Learn • Grow</p>
              </div>
            </div>
          </div>
        </div>
      </nav>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <MultiStepForm steps={steps} currentStep={1}>
          <div className="text-center mb-8">
            <p className="text-slate-600">We found students who complement your skills perfectly</p>
          </div>

          {/* AI Matching Status */}
          <Card className="bg-gradient-to-r from-accent/10 to-primary/10 border-0 mb-8">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center">
                    <Lightbulb className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <p className="font-medium text-slate-800">AI Analysis Complete</p>
                    <p className="text-sm text-slate-600">
                      {isLoading || findMatchesMutation.isPending 
                        ? 'Finding your perfect matches...'
                        : `Found ${matches.length} high-confidence matches (85%+ compatibility)`
                      }
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-accent">TF-IDF + Cosine Similarity</p>
                  <p className="text-xs text-slate-500">AI-powered matching</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Loading State */}
          {(isLoading || findMatchesMutation.isPending) && (
            <div className="text-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
              <p className="text-slate-600">Finding your perfect matches...</p>
            </div>
          )}

          {/* No Matches */}
          {!isLoading && !findMatchesMutation.isPending && matches.length === 0 && (
            <div className="text-center py-12">
              <div className="w-16 h-16 bg-gradient-to-br from-slate-300 to-slate-400 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">🔍</span>
              </div>
              <h3 className="text-xl font-bold text-slate-800 mb-2">No Matches Found</h3>
              <p className="text-slate-600 mb-4">
                Try expanding your skills or availability to find more matches
              </p>
              <Button onClick={() => goBack()}>
                Update Profile
              </Button>
            </div>
          )}

          {/* Match Cards */}
          {matches.length > 0 && (
            <div className="space-y-6">
              {matches.map((match: any) => (
                <MatchCard
                  key={match.id}
                  match={match}
                  onAccept={handleAcceptMatch}
                  onReject={handleRejectMatch}
                />
              ))}
            </div>
          )}

          {/* Navigation */}
          <div className="flex space-x-4 mt-8">
            <Button 
              variant="outline"
              className="flex-1"
              onClick={goBack}
            >
              ← Back to Profile
            </Button>
            <Button 
              className="flex-1 bg-gradient-to-r from-primary to-secondary hover:shadow-lg transform hover:scale-105 transition-all duration-200"
              onClick={viewResults}
              disabled={matches.length === 0}
            >
              View Results →
            </Button>
          </div>
        </MultiStepForm>
      </div>
      <NotificationToast
        {...notification}
        onClose={hideNotification}
      />
    </div>
  );
}
