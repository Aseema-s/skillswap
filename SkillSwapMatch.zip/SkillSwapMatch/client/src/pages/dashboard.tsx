import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MultiStepForm } from "@/components/ui/multi-step-form";
import { NotificationToast } from "@/components/ui/notification-toast";
import { CheckCircle, Trophy, Target, Users, MessageCircle } from "lucide-react";

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const [notification, setNotification] = useState<{
    show: boolean;
    title: string;
    message: string;
    type: 'success' | 'error' | 'info';
  }>({ show: false, title: '', message: '', type: 'success' });

  // Get userId from URL params
  const urlParams = new URLSearchParams(window.location.search);
  const userId = urlParams.get('userId');

  // Fetch user's connections
  const { data: connections = [] } = useQuery({
    queryKey: [`/api/users/${userId}/connections`],
    enabled: !!userId,
  });

  // Fetch user data
  const { data: user } = useQuery({
    queryKey: [`/api/users/${userId}`],
    enabled: !!userId,
  });

  const showNotification = (title: string, message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setNotification({ show: true, title, message, type });
  };

  const hideNotification = () => {
    setNotification(prev => ({ ...prev, show: false }));
  };

  const goBack = () => {
    setLocation(`/matching?userId=${userId}`);
  };

  const goToDashboard = () => {
    showNotification('Welcome!', 'Your skill exchange journey begins now', 'success');
    // In a real app, this would navigate to the main dashboard
    setTimeout(() => {
      setLocation('/');
    }, 2000);
  };

  if (!userId) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-slate-800 mb-4">Session Required</h2>
          <p className="text-slate-600 mb-4">Please complete the setup process first</p>
          <Button onClick={() => setLocation('/registration')}>
            Start Over
          </Button>
        </div>
      </div>
    );
  }

  const steps = [
    { title: "Welcome to SkillSync! 🎉", description: "Complete" }
  ];

  const getInitials = (name: string = "User") => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b border-slate-200">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-xl flex items-center justify-center shadow-lg">
                <span className="text-white font-bold text-lg">SS</span>
              </div>
              <div>
                <h1 className="text-xl font-bold text-slate-800">SkillSync</h1>
                <p className="text-xs text-slate-500">Connect • Learn • Grow</p>
              </div>
            </div>
            
            {/* User Info */}
            {user && (
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-slate-200 rounded-full flex items-center justify-center">
                  <span className="text-xs font-medium text-slate-700">
                    {getInitials(user.name)}
                  </span>
                </div>
                <span className="text-sm font-medium text-slate-700">{user.name}</span>
              </div>
            )}
          </div>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <MultiStepForm steps={steps} currentStep={1}>
          <div className="text-center mb-8">
            <p className="text-slate-600">You're all set up and ready to start learning and teaching</p>
          </div>

          {/* Success Animation */}
          <div className="text-center mb-8">
            <div className="w-20 h-20 bg-gradient-to-br from-accent to-primary rounded-full flex items-center justify-center mx-auto mb-4 animate-bounce">
              <CheckCircle className="w-10 h-10 text-white" />
            </div>
          </div>

          {/* Match Results Summary */}
          <div className="grid md:grid-cols-3 gap-6 mb-8">
            <Card className="bg-gradient-to-br from-accent/10 to-accent/5 border-0">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center mx-auto mb-3">
                  <Users className="w-6 h-6 text-white" />
                </div>
                <p className="font-bold text-slate-800">{connections.length} Connections Made</p>
                <p className="text-sm text-slate-600">Ready to start learning!</p>
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-br from-primary/10 to-primary/5 border-0">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mx-auto mb-3">
                  <Target className="w-6 h-6 text-white" />
                </div>
                <p className="font-bold text-slate-800">{user?.skills?.length || 0} Skills</p>
                <p className="text-sm text-slate-600">Ready to share</p>
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-br from-secondary/10 to-secondary/5 border-0">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-secondary rounded-full flex items-center justify-center mx-auto mb-3">
                  <Trophy className="w-6 h-6 text-white" />
                </div>
                <p className="font-bold text-slate-800">{user?.points || 0} Points</p>
                <p className="text-sm text-slate-600">Keep growing!</p>
              </CardContent>
            </Card>
          </div>

          {/* Active Connections */}
          {connections.length > 0 && (
            <div className="mb-8">
              <h3 className="text-lg font-bold text-slate-800 mb-4">Your Active Connections</h3>
              <div className="space-y-4">
                {connections.map((connection: any) => (
                  <Card key={connection.id} className="bg-slate-50 border-0">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center">
                            <span className="text-white font-bold">
                              {getInitials(connection.otherUser?.name)}
                            </span>
                          </div>
                          <div>
                            <p className="font-medium text-slate-800">{connection.otherUser?.name}</p>
                            <p className="text-sm text-slate-600">
                              Skills: {connection.skillsOffered?.slice(0, 2).join(', ')}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-3">
                          <Badge className="bg-accent/10 text-accent">Active</Badge>
                          <Button size="sm" variant="outline">
                            <MessageCircle className="w-4 h-4 mr-1" />
                            Message
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* Gamification Elements */}
          <div className="mb-8">
            <h3 className="text-lg font-bold text-slate-800 mb-4">Your Progress</h3>
            <div className="grid md:grid-cols-2 gap-6">
              {/* Badges */}
              <Card className="bg-gradient-to-br from-yellow-50 to-yellow-100 border-0">
                <CardContent className="p-6">
                  <h4 className="font-bold text-slate-800 mb-3">Badges Earned</h4>
                  <div className="flex flex-wrap gap-2">
                    {user?.badges?.map((badge: string, index: number) => (
                      <Badge key={index} className="bg-white text-yellow-600">
                        🏆 {badge}
                      </Badge>
                    )) || (
                      <Badge className="bg-white text-yellow-600">
                        🏆 First Connection
                      </Badge>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Leaderboard */}
              <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-0">
                <CardContent className="p-6">
                  <h4 className="font-bold text-slate-800 mb-3">College Leaderboard</h4>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">1. Top Student</span>
                      <span className="text-sm font-medium text-primary">2,450 pts</span>
                    </div>
                    <div className="flex items-center justify-between bg-white rounded px-2 py-1">
                      <span className="text-sm font-medium">2. You</span>
                      <span className="text-sm font-medium text-accent">{user?.points || 100} pts</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">3. Another Student</span>
                      <span className="text-sm font-medium text-primary">1,650 pts</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Next Steps */}
          <Card className="bg-gradient-to-r from-primary/5 to-secondary/5 border-0 mb-8">
            <CardContent className="p-6">
              <h3 className="text-lg font-bold text-slate-800 mb-4">What's Next?</h3>
              <div className="grid md:grid-cols-3 gap-4">
                <div className="text-center">
                  <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mx-auto mb-2">
                    <MessageCircle className="w-6 h-6 text-white" />
                  </div>
                  <p className="font-medium text-slate-800">Start Conversations</p>
                  <p className="text-sm text-slate-600">Message your matches</p>
                </div>
                
                <div className="text-center">
                  <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center mx-auto mb-2">
                    <Target className="w-6 h-6 text-white" />
                  </div>
                  <p className="font-medium text-slate-800">Schedule Sessions</p>
                  <p className="text-sm text-slate-600">Book learning slots</p>
                </div>
                
                <div className="text-center">
                  <div className="w-12 h-12 bg-secondary rounded-full flex items-center justify-center mx-auto mb-2">
                    <Trophy className="w-6 h-6 text-white" />
                  </div>
                  <p className="font-medium text-slate-800">Give Endorsements</p>
                  <p className="text-sm text-slate-600">Rate your experiences</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Action Button */}
          <div className="text-center">
            <Button 
              className="bg-gradient-to-r from-primary to-secondary text-white py-4 px-8 rounded-lg font-bold text-lg hover:shadow-lg transform hover:scale-105 transition-all duration-200"
              onClick={goToDashboard}
            >
              Go to Dashboard 🚀
            </Button>
          </div>
        </MultiStepForm>
      </div>

      <NotificationToast
        {...notification}
        onClose={hideNotification}
      />
    </div>
  );
}
