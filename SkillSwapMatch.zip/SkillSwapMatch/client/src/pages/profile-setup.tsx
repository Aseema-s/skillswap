import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { MultiStepForm } from "@/components/ui/multi-step-form";
import { SkillSelector } from "@/components/ui/skill-selector";
import { TimeSlotSelector } from "@/components/ui/time-slot-selector";
import { NotificationToast } from "@/components/ui/notification-toast";
import { apiRequest } from "@/lib/queryClient";
import { TIME_SLOTS } from "@shared/schema";

const profileSchema = z.object({
  skills: z.array(z.string()).min(1, "Please select at least one skill"),
  availability: z.array(z.string()).min(1, "Please select at least one time slot"),
});

type ProfileFormData = z.infer<typeof profileSchema>;

export default function ProfileSetup() {
  const [, setLocation] = useLocation();
  const [notification, setNotification] = useState<{
    show: boolean;
    title: string;
    message: string;
    type: 'success' | 'error' | 'info';
  }>({ show: false, title: '', message: '', type: 'success' });

  // Get userId from URL params
  const urlParams = new URLSearchParams(window.location.search);
  const userId = urlParams.get('userId');

  const form = useForm<ProfileFormData>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      skills: [],
      availability: [],
    },
  });

  // Fetch skills list
  const { data: availableSkills = [] } = useQuery({
    queryKey: ['/api/skills'],
  });

  // Update profile mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (data: ProfileFormData) => {
      if (!userId) throw new Error('User ID is required');
      const response = await apiRequest('PATCH', `/api/users/${userId}`, data);
      return response.json();
    },
    onSuccess: () => {
      showNotification('Profile Updated!', 'Let\'s find your perfect matches', 'success');
      setTimeout(() => {
        setLocation(`/matching?userId=${userId}`);
      }, 1500);
    },
    onError: (error: any) => {
      showNotification('Update Failed', error.message || 'Please try again', 'error');
    },
  });

  const showNotification = (title: string, message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setNotification({ show: true, title, message, type });
  };

  const hideNotification = () => {
    setNotification(prev => ({ ...prev, show: false }));
  };

  const onSubmit = (data: ProfileFormData) => {
    updateProfileMutation.mutate(data);
  };

  const goBack = () => {
    setLocation('/registration');
  };

  if (!userId) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-slate-800 mb-4">Session Required</h2>
          <p className="text-slate-600 mb-4">Please complete registration first</p>
          <Button onClick={() => setLocation('/registration')}>
            Go to Registration
          </Button>
        </div>
      </div>
    );
  }

  const steps = [
    { title: "Tell us about yourself! ✨", description: "Build Your Profile" }
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b border-slate-200">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-xl flex items-center justify-center shadow-lg">
                <span className="text-white font-bold text-lg">SS</span>
              </div>
              <div>
                <h1 className="text-xl font-bold text-slate-800">SkillSync</h1>
                <p className="text-xs text-slate-500">Connect • Learn • Grow</p>
              </div>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <MultiStepForm steps={steps} currentStep={1}>
          <div className="text-center mb-8">
            <p className="text-slate-600">Help us find the perfect skill matches for you</p>
          </div>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
              {/* Skills Selection */}
              <FormField
                control={form.control}
                name="skills"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-base font-medium">Your Skills</FormLabel>
                    <FormControl>
                      <SkillSelector
                        availableSkills={availableSkills}
                        selectedSkills={field.value}
                        onSkillsChange={field.onChange}
                        placeholder="Search skills... (e.g., Python, Design, Marketing)"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Availability Selection */}
              <FormField
                control={form.control}
                name="availability"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <TimeSlotSelector
                        timeSlots={TIME_SLOTS}
                        selectedSlots={field.value}
                        onSlotsChange={field.onChange}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex space-x-4">
                <Button 
                  type="button"
                  variant="outline"
                  className="flex-1"
                  onClick={goBack}
                >
                  ← Back
                </Button>
                <Button 
                  type="submit" 
                  className="flex-1 bg-gradient-to-r from-primary to-secondary hover:shadow-lg transform hover:scale-105 transition-all duration-200"
                  disabled={updateProfileMutation.isPending}
                >
                  {updateProfileMutation.isPending ? 'Saving...' : 'Find My Matches 🔍'}
                </Button>
              </div>
            </form>
          </Form>
        </MultiStepForm>
      </div>

      <NotificationToast
        {...notification}
        onClose={hideNotification}
      />
    </div>
  );
}
