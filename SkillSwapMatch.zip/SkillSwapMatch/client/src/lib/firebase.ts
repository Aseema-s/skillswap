import { initializeApp } from "firebase/app";
import { getAuth, signInWithRedirect, GoogleAuthProvider, getRedirectResult, signOut, onAuthStateChanged, User } from "firebase/auth";
import { getAnalytics } from "firebase/analytics";

const firebaseConfig = {
  apiKey: "AIzaSyBjwgdWGcYw_YCrxItCYajbBUN2-fZXmlc",
  authDomain: "skill-swap-f5782.firebaseapp.com",
  projectId: "skill-swap-f5782",
  storageBucket: "skill-swap-f5782.firebasestorage.app",
  messagingSenderId: "998296683746",
  appId: "1:998296683746:web:a99cd8a6bb9900c8c2cabb",
  measurementId: "G-51ZKRX67SR"
};

const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
export const auth = getAuth(app);
export { analytics };

const provider = new GoogleAuthProvider();
provider.addScope('email');
provider.addScope('profile');

export const signInWithGoogle = async () => {
  try {
    return await signInWithRedirect(auth, provider);
  } catch (error) {
    console.error("Google sign-in error:", error);
    throw error;
  }
};

export const handleRedirectResult = async () => {
  try {
    return await getRedirectResult(auth);
  } catch (error) {
    console.error("Firebase redirect result error:", error);
    throw error;
  }
};

export const signOutUser = async () => {
  try {
    return await signOut(auth);
  } catch (error) {
    console.error("Sign out error:", error);
    throw error;
  }
};

export const onAuthStateChange = (callback: (user: User | null) => void) => {
  return onAuthStateChanged(auth, callback);
};

export { GoogleAuthProvider };
