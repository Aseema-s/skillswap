import { User } from "@shared/schema";

interface MatchResult {
  user: User;
  score: number;
  commonSkills: string[];
  commonAvailability: string[];
}

// Simple TF-IDF inspired similarity calculation
export function calculateSimilarity(user1: User, user2: User): number {
  const skills1 = new Set(user1.skills);
  const skills2 = new Set(user2.skills);
  const availability1 = new Set(user1.availability);
  const availability2 = new Set(user2.availability);

  // Calculate Jaccard similarity for skills
  const skillsIntersection = new Set([...skills1].filter(x => skills2.has(x)));
  const skillsUnion = new Set([...skills1, ...skills2]);
  const skillsSimilarity = skillsIntersection.size / skillsUnion.size;

  // Calculate Jaccard similarity for availability
  const availabilityIntersection = new Set([...availability1].filter(x => availability2.has(x)));
  const availabilityUnion = new Set([...availability1, ...availability2]);
  const availabilitySimilarity = availabilityIntersection.size / availabilityUnion.size;

  // College bonus (same college gets extra points)
  const collegeBonus = user1.college === user2.college ? 0.1 : 0;

  // Complementary skills bonus (different skills that can be exchanged)
  const user1CanTeach = [...skills1].filter(skill => !skills2.has(skill));
  const user2CanTeach = [...skills2].filter(skill => !skills1.has(skill));
  const complementaryBonus = (user1CanTeach.length > 0 && user2CanTeach.length > 0) ? 0.2 : 0;

  // Weighted combination
  const totalScore = (
    skillsSimilarity * 0.4 + 
    availabilitySimilarity * 0.3 + 
    collegeBonus + 
    complementaryBonus
  );

  return Math.min(totalScore, 1.0); // Cap at 1.0
}

export function findBestMatches(currentUser: User, allUsers: User[]): MatchResult[] {
  const matches: MatchResult[] = [];

  for (const user of allUsers) {
    const score = calculateSimilarity(currentUser, user);
    
    // Only consider matches above threshold (equivalent to score > 0.1)
    if (score > 0.3) {
      const commonSkills = currentUser.skills.filter(skill => user.skills.includes(skill));
      const commonAvailability = currentUser.availability.filter(slot => user.availability.includes(slot));
      
      matches.push({
        user,
        score,
        commonSkills,
        commonAvailability
      });
    }
  }

  // Sort by similarity score (descending) and return top 3
  return matches
    .sort((a, b) => b.score - a.score)
    .slice(0, 3);
}

export function getComplementarySkills(user1: User, user2: User) {
  const user1CanTeach = user1.skills.filter(skill => !user2.skills.includes(skill));
  const user2CanTeach = user2.skills.filter(skill => !user1.skills.includes(skill));
  const user1WantsToLearn = user2.skills.filter(skill => !user1.skills.includes(skill));
  const user2WantsToLearn = user1.skills.filter(skill => !user2.skills.includes(skill));

  return {
    user1CanTeach,
    user2CanTeach,
    user1WantsToLearn,
    user2WantsToLearn
  };
}
