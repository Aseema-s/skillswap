import { useState } from "react";
import { Card, CardContent } from "./card";
import { Button } from "./button";
import { Badge } from "./badge";
import { Star } from "lucide-react";
import { User } from "@shared/schema";

interface MatchCardProps {
  match: {
    id: number;
    matchedUser: User;
    similarityScore: number;
    commonSkills?: string[];
    commonAvailability?: string[];
  };
  onAccept: (matchId: number) => void;
  onReject: (matchId: number) => void;
}

export function MatchCard({ match, onAccept, onReject }: MatchCardProps) {
  const [isProcessing, setIsProcessing] = useState(false);
  const { matchedUser, similarityScore, commonSkills = [], commonAvailability = [] } = match;

  const handleAccept = async () => {
    setIsProcessing(true);
    await onAccept(match.id);
    setIsProcessing(false);
  };

  const handleReject = async () => {
    setIsProcessing(true);
    await onReject(match.id);
    setIsProcessing(false);
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  const getAvailabilityStatus = () => {
    return commonAvailability.length > 0 ? 'Available Now' : 'Limited Availability';
  };

  const getAvailabilityColor = () => {
    return commonAvailability.length > 0 ? 'bg-primary/10 text-primary' : 'bg-warning/10 text-warning';
  };

  // Find complementary skills
  const canTeachYou = matchedUser.skills.filter(skill => !commonSkills.includes(skill));
  const wantsToLearn = matchedUser.skills.filter(skill => commonSkills.includes(skill));

  return (
    <Card className="match-card bg-white border-2 border-slate-200 hover:border-primary/30 transition-all">
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center space-x-4">
            {/* Profile Avatar */}
            <div className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center">
              <span className="text-white font-bold text-xl">
                {getInitials(matchedUser.name)}
              </span>
            </div>
            
            <div>
              <h3 className="font-bold text-lg text-slate-800">{matchedUser.name}</h3>
              <p className="text-slate-600 text-sm">{matchedUser.college}</p>
              <div className="flex items-center space-x-2 mt-1">
                <Badge className="bg-accent/10 text-accent">
                  {Math.round(similarityScore * 100)}% Match
                </Badge>
                <Badge className={getAvailabilityColor()}>
                  {getAvailabilityStatus()}
                </Badge>
              </div>
            </div>
          </div>
          
          <div className="text-right">
            <div className="flex items-center space-x-1 mb-1">
              <Star className="w-4 h-4 text-yellow-400 fill-current" />
              <span className="text-sm font-medium text-slate-700">
                {(matchedUser.rating || 4.5).toFixed(1)}
              </span>
            </div>
            <p className="text-xs text-slate-500">
              {matchedUser.endorsements || 0} endorsements
            </p>
          </div>
        </div>

        {/* Skills they can teach you */}
        {canTeachYou.length > 0 && (
          <div className="mb-4">
            <p className="text-sm font-medium text-slate-700 mb-2">Can teach you:</p>
            <div className="flex flex-wrap gap-2">
              {canTeachYou.slice(0, 3).map((skill) => (
                <Badge key={skill} className="bg-accent/10 text-accent">
                  {skill}
                </Badge>
              ))}
              {canTeachYou.length > 3 && (
                <Badge className="bg-slate-100 text-slate-600">
                  +{canTeachYou.length - 3} more
                </Badge>
              )}
            </div>
          </div>
        )}

        {/* Skills they want to learn */}
        {commonSkills.length > 0 && (
          <div className="mb-4">
            <p className="text-sm font-medium text-slate-700 mb-2">Wants to learn:</p>
            <div className="flex flex-wrap gap-2">
              {commonSkills.slice(0, 3).map((skill) => (
                <Badge key={skill} className="bg-secondary/10 text-secondary">
                  {skill}
                </Badge>
              ))}
              {commonSkills.length > 3 && (
                <Badge className="bg-slate-100 text-slate-600">
                  +{commonSkills.length - 3} more
                </Badge>
              )}
            </div>
          </div>
        )}

        {/* Common availability */}
        {commonAvailability.length > 0 && (
          <div className="mb-6">
            <p className="text-sm font-medium text-slate-700 mb-2">Common availability:</p>
            <div className="flex flex-wrap gap-2">
              {commonAvailability.map((slot) => (
                <Badge key={slot} variant="outline" className="text-slate-700">
                  {slot}
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex space-x-3">
          <Button
            variant="outline"
            className="flex-1"
            onClick={handleReject}
            disabled={isProcessing}
          >
            <span className="mr-2">✋</span>
            Pass
          </Button>
          <Button
            className="flex-1 bg-gradient-to-r from-accent to-primary hover:shadow-lg transform hover:scale-105 transition-all duration-200"
            onClick={handleAccept}
            disabled={isProcessing}
          >
            <span className="mr-2">🤝</span>
            Connect
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
