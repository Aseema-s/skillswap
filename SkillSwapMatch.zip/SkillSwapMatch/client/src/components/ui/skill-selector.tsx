import { useState } from "react";
import { Input } from "./input";
import { Badge } from "./badge";
import { Button } from "./button";
import { X } from "lucide-react";

interface SkillSelectorProps {
  availableSkills: string[];
  selectedSkills: string[];
  onSkillsChange: (skills: string[]) => void;
  placeholder?: string;
}

export function SkillSelector({ 
  availableSkills, 
  selectedSkills, 
  onSkillsChange,
  placeholder = "Search skills..."
}: SkillSelectorProps) {
  const [searchTerm, setSearchTerm] = useState("");

  const filteredSkills = availableSkills.filter(skill => 
    skill.toLowerCase().includes(searchTerm.toLowerCase()) &&
    !selectedSkills.includes(skill)
  );

  const popularSkills = [
    "Python", "JavaScript", "UI/UX Design", "Digital Marketing", 
    "Data Science", "Photography", "Content Writing", "Video Editing"
  ].filter(skill => !selectedSkills.includes(skill));

  const addSkill = (skill: string) => {
    if (!selectedSkills.includes(skill)) {
      onSkillsChange([...selectedSkills, skill]);
    }
  };

  const removeSkill = (skill: string) => {
    onSkillsChange(selectedSkills.filter(s => s !== skill));
  };

  return (
    <div className="space-y-4">
      {/* Search Input */}
      <Input
        type="text"
        placeholder={placeholder}
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        className="w-full"
      />

      {/* Popular Skills */}
      {!searchTerm && (
        <div>
          <p className="text-sm text-slate-600 mb-3">Popular Skills:</p>
          <div className="flex flex-wrap gap-2">
            {popularSkills.map((skill) => (
              <Button
                key={skill}
                type="button"
                variant="outline"
                size="sm"
                className="skill-chip hover:bg-primary hover:text-white transition-all"
                onClick={() => addSkill(skill)}
              >
                {skill}
              </Button>
            ))}
          </div>
        </div>
      )}

      {/* Search Results */}
      {searchTerm && filteredSkills.length > 0 && (
        <div>
          <p className="text-sm text-slate-600 mb-3">Search Results:</p>
          <div className="flex flex-wrap gap-2 max-h-32 overflow-y-auto">
            {filteredSkills.slice(0, 10).map((skill) => (
              <Button
                key={skill}
                type="button"
                variant="outline"
                size="sm"
                className="skill-chip hover:bg-primary hover:text-white transition-all"
                onClick={() => addSkill(skill)}
              >
                {skill}
              </Button>
            ))}
          </div>
        </div>
      )}

      {/* Selected Skills */}
      <div>
        <p className="text-sm text-slate-600 mb-3">Selected Skills:</p>
        <div className="flex flex-wrap gap-2 min-h-[40px] p-3 border border-slate-300 rounded-lg bg-slate-50">
          {selectedSkills.length === 0 ? (
            <span className="text-slate-400 text-sm">No skills selected yet</span>
          ) : (
            selectedSkills.map((skill) => (
              <Badge
                key={skill}
                className="bg-primary text-white hover:bg-primary/80 transition-all animate-bounce-in"
              >
                {skill}
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="ml-1 h-auto p-0 text-white hover:text-slate-200"
                  onClick={() => removeSkill(skill)}
                >
                  <X className="w-3 h-3" />
                </Button>
              </Badge>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
