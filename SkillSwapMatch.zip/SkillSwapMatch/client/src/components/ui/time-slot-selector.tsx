import { Checkbox } from "./checkbox";
import { Label } from "./label";

interface TimeSlotSelectorProps {
  timeSlots: string[];
  selectedSlots: string[];
  onSlotsChange: (slots: string[]) => void;
}

export function TimeSlotSelector({ timeSlots, selectedSlots, onSlotsChange }: TimeSlotSelectorProps) {
  const toggleSlot = (slot: string) => {
    if (selectedSlots.includes(slot)) {
      onSlotsChange(selectedSlots.filter(s => s !== slot));
    } else {
      onSlotsChange([...selectedSlots, slot]);
    }
  };

  return (
    <div>
      <Label className="block text-sm font-medium text-slate-700 mb-3">
        When are you available?
      </Label>
      <p className="text-sm text-slate-500 mb-4">
        Select your preferred time slots (6 PM - 9 PM)
      </p>
      
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {timeSlots.map((slot) => (
          <Label
            key={slot}
            className="flex items-center space-x-3 p-3 border border-slate-300 rounded-lg hover:bg-slate-50 cursor-pointer transition-all"
          >
            <Checkbox
              checked={selectedSlots.includes(slot)}
              onCheckedChange={() => toggleSlot(slot)}
              className="text-primary border-slate-300 focus:ring-primary"
            />
            <span className="text-sm font-medium text-slate-700">{slot}</span>
          </Label>
        ))}
      </div>
    </div>
  );
}
