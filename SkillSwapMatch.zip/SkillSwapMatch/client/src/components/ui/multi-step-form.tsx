import { useState } from "react";
import { Progress } from "./progress";

interface Step {
  title: string;
  description: string;
}

interface MultiStepFormProps {
  steps: Step[];
  currentStep: number;
  children: React.ReactNode;
}

export function MultiStepForm({ steps, currentStep, children }: MultiStepFormProps) {
  const progress = (currentStep / steps.length) * 100;

  return (
    <div className="bg-white rounded-2xl shadow-xl p-8 mb-8 animate-fade-in">
      {/* Progress Indicator */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <span className="text-sm font-medium text-primary">
            Step {currentStep} of {steps.length}
          </span>
          <span className="text-sm text-slate-500">
            {steps[currentStep - 1]?.description}
          </span>
        </div>
        <Progress value={progress} className="h-2" />
      </div>

      {/* Step Title */}
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-slate-800 mb-2">
          {steps[currentStep - 1]?.title}
        </h2>
      </div>

      {/* Step Content */}
      {children}
    </div>
  );
}
