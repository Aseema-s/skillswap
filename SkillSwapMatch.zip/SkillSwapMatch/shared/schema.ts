import { pgTable, text, serial, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  password: text("password"),
  name: text("name").notNull(),
  college: text("college").notNull(),
  skills: text("skills").array().notNull(),
  availability: text("availability").array().notNull(),
  firebaseUid: text("firebase_uid").unique(),
  rating: integer("rating").default(0),
  endorsements: integer("endorsements").default(0),
  points: integer("points").default(0),
  badges: text("badges").array().default([]),
  createdAt: timestamp("created_at").defaultNow(),
});

export const matches = pgTable("matches", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  matchedUserId: integer("matched_user_id").notNull(),
  similarityScore: integer("similarity_score").notNull(), // percentage * 100
  status: text("status").notNull(), // 'pending', 'accepted', 'rejected'
  createdAt: timestamp("created_at").defaultNow(),
});

export const connections = pgTable("connections", {
  id: serial("id").primaryKey(),
  user1Id: integer("user1_id").notNull(),
  user2Id: integer("user2_id").notNull(),
  status: text("status").notNull(), // 'active', 'completed', 'cancelled'
  skillsOffered: text("skills_offered").array().notNull(),
  skillsWanted: text("skills_wanted").array().notNull(),
  nextSessionTime: text("next_session_time"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const sessions = pgTable("sessions", {
  id: serial("id").primaryKey(),
  connectionId: integer("connection_id").notNull(),
  scheduledTime: text("scheduled_time").notNull(),
  status: text("status").notNull(), // 'scheduled', 'completed', 'cancelled'
  rating: integer("rating"),
  feedback: text("feedback"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  rating: true,
  endorsements: true,
  points: true,
  badges: true,
  createdAt: true,
});

export const insertMatchSchema = createInsertSchema(matches).omit({
  id: true,
  createdAt: true,
});

export const insertConnectionSchema = createInsertSchema(connections).omit({
  id: true,
  createdAt: true,
});

export const insertSessionSchema = createInsertSchema(sessions).omit({
  id: true,
  createdAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertMatch = z.infer<typeof insertMatchSchema>;
export type Match = typeof matches.$inferSelect;
export type InsertConnection = z.infer<typeof insertConnectionSchema>;
export type Connection = typeof connections.$inferSelect;
export type InsertSession = z.infer<typeof insertSessionSchema>;
export type Session = typeof sessions.$inferSelect;

// Tamil Nadu colleges data
export const TAMIL_NADU_COLLEGES = [
  "Anna University, Chennai",
  "PSG College of Technology, Coimbatore",
  "Thiagarajar College of Engineering, Madurai",
  "National Institute of Technology, Trichy",
  "Coimbatore Institute of Technology",
  "Madras Institute of Technology",
  "SRM Institute of Science and Technology",
  "VIT University, Vellore",
  "Chennai Institute of Technology",
  "Kongu Engineering College",
  "Kumaraguru College of Technology",
  "Bannari Amman Institute of Technology",
  "Karunya Institute of Technology",
  "Amrita School of Engineering",
  "Hindustan Institute of Technology and Science",
  "Sathyabama Institute of Science and Technology",
  "St. Joseph's College of Engineering",
  "Rajalakshmi Engineering College",
  "Rajalakshmi Institute of Technology",
  "Sri Sairam Engineering College",
  "Easwari Engineering College"
];

// Skills data (LinkedIn-style comprehensive list)
export const SKILLS_DATA = [
  // Programming Languages
  "Python", "JavaScript", "Java", "C++", "C#", "PHP", "Ruby", "Go", "Rust", "Swift",
  "Kotlin", "TypeScript", "R", "MATLAB", "Scala", "Perl", "Objective-C",
  
  // Web Development
  "React", "Angular", "Vue.js", "Node.js", "HTML5", "CSS3", "Sass", "Less",
  "Bootstrap", "Tailwind CSS", "jQuery", "Express.js", "Next.js", "Nuxt.js",
  "Svelte", "Gatsby", "Django", "Flask", "Laravel", "Spring Boot", "ASP.NET",
  
  // Mobile Development
  "React Native", "Flutter", "iOS Development", "Android Development", "Xamarin",
  "Ionic", "PhoneGap", "Cordova",
  
  // Database Technologies
  "MySQL", "PostgreSQL", "MongoDB", "Redis", "SQLite", "Oracle", "SQL Server",
  "Firebase", "DynamoDB", "Cassandra", "Neo4j", "Elasticsearch",
  
  // Cloud & DevOps
  "AWS", "Azure", "Google Cloud", "Docker", "Kubernetes", "Jenkins", "GitLab CI",
  "GitHub Actions", "Terraform", "Ansible", "Chef", "Puppet", "Nagios", "Prometheus",
  
  // Data Science & AI
  "Machine Learning", "Deep Learning", "Data Science", "Artificial Intelligence",
  "TensorFlow", "PyTorch", "Scikit-learn", "Pandas", "NumPy", "Matplotlib",
  "Tableau", "Power BI", "Apache Spark", "Hadoop", "Kafka", "Airflow",
  
  // Design & Creative
  "UI/UX Design", "Graphic Design", "Adobe Photoshop", "Adobe Illustrator",
  "Adobe XD", "Figma", "Sketch", "InVision", "Canva", "After Effects",
  "Premiere Pro", "Blender", "Maya", "3D Modeling", "Animation",
  
  // Marketing & Business
  "Digital Marketing", "Content Marketing", "Social Media Marketing", "SEO",
  "SEM", "Google Ads", "Facebook Ads", "Email Marketing", "Affiliate Marketing",
  "Brand Management", "Project Management", "Agile", "Scrum", "Kanban",
  
  // Media & Content
  "Photography", "Video Editing", "Content Writing", "Copywriting", "Blogging",
  "Podcasting", "Video Production", "Audio Editing", "Voice Over",
  "Technical Writing", "Creative Writing",
  
  // Languages
  "English", "Tamil", "Hindi", "French", "Spanish", "German", "Japanese",
  "Chinese", "Korean", "Arabic", "Portuguese", "Italian",
  
  // Other Technical Skills
  "Cybersecurity", "Blockchain", "IoT", "Robotics", "Game Development",
  "Unity", "Unreal Engine", "Virtual Reality", "Augmented Reality",
  "Embedded Systems", "FPGA", "PCB Design", "CAD", "AutoCAD", "SolidWorks"
];

// Time slots for availability (6 PM to 9 PM in 30-min intervals)
export const TIME_SLOTS = [
  "6:00-6:30 PM",
  "6:30-7:00 PM", 
  "7:00-7:30 PM",
  "7:30-8:00 PM",
  "8:00-8:30 PM",
  "8:30-9:00 PM"
];
