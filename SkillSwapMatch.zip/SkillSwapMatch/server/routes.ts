import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertMatchSchema, insertConnectionSchema, TAMIL_NADU_COLLEGES, SKILLS_DATA } from "@shared/schema";
import { calculateSimilarity, findBestMatches } from "../client/src/lib/matching";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get colleges list
  app.get("/api/colleges", async (req, res) => {
    res.json(TAMIL_NADU_COLLEGES);
  });

  // Get skills list
  app.get("/api/skills", async (req, res) => {
    res.json(SKILLS_DATA);
  });

  // User registration
  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists with this email" });
      }

      const user = await storage.createUser(userData);
      res.json(user);
    } catch (error) {
      console.error("Error creating user:", error);
      res.status(400).json({ message: "Invalid user data" });
    }
  });

  // Get user by Firebase UID
  app.get("/api/users/firebase/:uid", async (req, res) => {
    try {
      const user = await storage.getUserByFirebaseUid(req.params.uid);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Update user profile
  app.patch("/api/users/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const updates = req.body;
      
      const user = await storage.updateUser(userId, updates);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(user);
    } catch (error) {
      console.error("Error updating user:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Find matches for a user
  app.post("/api/matches/find", async (req, res) => {
    try {
      const { userId } = req.body;
      
      const currentUser = await storage.getUser(userId);
      if (!currentUser) {
        return res.status(404).json({ message: "User not found" });
      }

      const allUsers = await storage.getAllUsers();
      const otherUsers = allUsers.filter(user => user.id !== userId);
      
      // Calculate similarity scores and find best matches
      const matches = findBestMatches(currentUser, otherUsers);
      
      // Save matches to database
      const savedMatches = [];
      for (const match of matches) {
        const matchData = {
          userId: userId,
          matchedUserId: match.user.id,
          similarityScore: Math.round(match.score * 100),
          status: 'pending'
        };
        
        const savedMatch = await storage.createMatch(matchData);
        savedMatches.push({
          ...savedMatch,
          matchedUser: match.user,
          similarityScore: match.score,
          commonSkills: match.commonSkills,
          commonAvailability: match.commonAvailability
        });
      }
      
      res.json(savedMatches);
    } catch (error) {
      console.error("Error finding matches:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Accept/reject match
  app.patch("/api/matches/:id", async (req, res) => {
    try {
      const matchId = parseInt(req.params.id);
      const { status } = req.body; // 'accepted' or 'rejected'
      
      const match = await storage.updateMatchStatus(matchId, status);
      if (!match) {
        return res.status(404).json({ message: "Match not found" });
      }

      // If accepted, create a connection
      if (status === 'accepted') {
        const user1 = await storage.getUser(match.userId);
        const user2 = await storage.getUser(match.matchedUserId);
        
        if (user1 && user2) {
          // Find complementary skills
          const user1CanTeach = user1.skills.filter(skill => user2.skills.includes(skill) === false);
          const user2CanTeach = user2.skills.filter(skill => user1.skills.includes(skill) === false);
          
          const connection = await storage.createConnection({
            user1Id: match.userId,
            user2Id: match.matchedUserId,
            status: 'active',
            skillsOffered: user1CanTeach,
            skillsWanted: user2CanTeach,
            nextSessionTime: null
          });

          // Update user points
          await storage.updateUser(match.userId, { 
            points: (user1.points || 0) + 50 
          });
          await storage.updateUser(match.matchedUserId, { 
            points: (user2.points || 0) + 50 
          });

          res.json({ match, connection });
        }
      } else {
        res.json(match);
      }
    } catch (error) {
      console.error("Error updating match:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get user's connections
  app.get("/api/users/:id/connections", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const connections = await storage.getConnectionsByUserId(userId);
      
      // Populate with user details
      const populatedConnections = [];
      for (const connection of connections) {
        const otherUserId = connection.user1Id === userId ? connection.user2Id : connection.user1Id;
        const otherUser = await storage.getUser(otherUserId);
        
        if (otherUser) {
          populatedConnections.push({
            ...connection,
            otherUser
          });
        }
      }
      
      res.json(populatedConnections);
    } catch (error) {
      console.error("Error fetching connections:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get user's matches
  app.get("/api/users/:id/matches", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const matches = await storage.getMatchesByUserId(userId);
      
      // Populate with matched user details
      const populatedMatches = [];
      for (const match of matches) {
        const matchedUser = await storage.getUser(match.matchedUserId);
        if (matchedUser) {
          populatedMatches.push({
            ...match,
            matchedUser
          });
        }
      }
      
      res.json(populatedMatches);
    } catch (error) {
      console.error("Error fetching matches:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Schedule a session
  app.post("/api/sessions", async (req, res) => {
    try {
      const sessionData = req.body;
      const session = await storage.createSession(sessionData);
      res.json(session);
    } catch (error) {
      console.error("Error creating session:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
